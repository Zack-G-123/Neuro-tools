# Neuro Exam Toolkit — GitHub Pages PWA (fixed install build)

Upload **all files in this folder directly to the repository root**. There is no required subfolder.

## Required files

- `index.html`
- `manifest.json`
- `service-worker.js`
- `icon-192.png`
- `icon-512.png`
- `icon-maskable-512.png`
- `apple-touch-icon.png`
- `favicon-64.png`
- `icon.svg`
- `.nojekyll`

## GitHub Pages

1. Commit/push all files to the root of your repository.
2. GitHub → repository **Settings → Pages**.
3. Source: **Deploy from a branch**.
4. Branch: `main`, folder: `/(root)`.
5. Wait for the Pages deployment to finish.
6. Open the final `https://<username>.github.io/<repository>/` URL.

## IMPORTANT: remove the old installed shortcut first

If you already added the broken shortcut/PWA from the previous build:

### Android / Chrome
1. Remove the old Home Screen shortcut/app.
2. In Chrome, open the new Pages URL.
3. Reload once after the new deployment is live.
4. Open **Settings inside Neuro Exam Toolkit → App & offline**.
5. Confirm it says the **PWA service worker is active and controlling this page**.
6. Chrome menu should then offer **Install app**. Use that, not a menu item that explicitly says it will create only a shortcut.

### iPhone / iPad
1. Remove any prior Home Screen version.
2. Open the Pages URL in Safari.
3. Share → **Add to Home Screen**.
4. Keep **Open as Web App** enabled if shown.
5. Add.

## Why this build is different

The previous service worker blocked its own installation while trying to download cross-origin NIHSS/Ishihara resources. This build caches only the local application shell during installation, so activation is immediate. External clinical resources are cached opportunistically later and can never prevent PWA installability.

The PWA files and icons are also flattened into the repository root, matching the simpler structure used by the working Stroke Code Logger PWA and avoiding folder/path mistakes during GitHub upload.

Favorites/settings remain in `localStorage` on the device.
